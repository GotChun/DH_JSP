package Controller.Book;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Domain.Common.Service.BookServiceImpl;

public class BookUpdateController implements SubController{

	private BookServiceImpl bookService;
	
	public BookUpdateController() {
		try {
			bookService = BookServiceImpl.getInstance();	
		} catch (Exception e) {
			//ExceptionHandler 로 전달..
		}
	}
	
	
	//예외처리함수
	public void ExceptionHandler(Exception e,HttpServletRequest req,HttpServletResponse resp) throws ServletException{
		try {
			req.setAttribute("exception", e);
			req.getRequestDispatcher("/WEB-INF/view/book/error.jsp").forward(req, resp);
		}catch(Exception ex) {
			throw new ServletException(ex);
		}
	}

	
	
	
}
