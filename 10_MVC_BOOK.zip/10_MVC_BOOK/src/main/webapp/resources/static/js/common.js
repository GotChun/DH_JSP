/**
 * 
 */

console.log("common.js..!!");